<?php
?>
<font size="+1">VMware Status</font>
<br><br><br>
<table border="0">
	<tr>
		<td><b>Plugin Version</b></td>
		<td><?php echo trim(shell_exec('plugin version /boot/config/plugins/openVMTools_compiled.plg'))?></td>
	</tr>
	<tr>
		<td><b>VMware Tools Version</b></td>
		<td><?php echo trim(shell_exec('/usr/local/bin/vmware-toolbox-cmd -v'))?></td>
	</tr>
	<tr>
		<td><b>Host Version</b></td>
		<td><?php echo trim(shell_exec('/usr/local/bin/vmware-toolbox-cmd stat raw text session | grep version | sed "s/version = //"'))?></td>
	</tr>
	<tr>
		<td><b>Host Time</b></td>
		<td><?php echo trim(shell_exec('/usr/local/bin/vmware-toolbox-cmd stat hosttime'))?></td>
	</tr>
	<tr>
		<td><b>Time Sync</b></td>
		<td><?php echo trim(shell_exec('/usr/local/bin/vmware-toolbox-cmd timesync status'))?></td>
	</tr>
</table>
<?php
